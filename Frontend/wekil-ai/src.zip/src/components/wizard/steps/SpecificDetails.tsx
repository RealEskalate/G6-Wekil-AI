"use client";

import React from "react";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Label } from "@/components/ui/Label";
import { toast } from "sonner";
import { Language, ContractData } from "@/components/wizard/ContractWizard";

interface SpecificDetailsProps {
  currentLanguage: Language;
  onNext: (data: Partial<ContractData>) => void;
  contractType?: string;
}

export default function SpecificDetails({ currentLanguage, onNext, contractType }: SpecificDetailsProps) {
  const [specificDetails, setSpecificDetails] = useState<Partial<{
    servicesDescription: string;
    milestones: { description: string; date: string }[];
    revisions: number;
    items: { description: string; quantity: number; unitPrice: number }[];
    deliveryTerms: string;
    principalAmount: number;
    installments: { amount: number; dueDate: string }[];
    lateFeePercentage: number;
    effectiveDate: string;
    confidentialityPeriod: number;
    purpose: string;
  }>>({});

  const t = {
    en: {
      title: "Specific Details",
      subtitle: "Enter details specific to your agreement",
      servicesDescription: "Services Description",
      milestoneDescription: "Milestone Description",
      milestoneDate: "Milestone Date",
      revisions: "Number of Revisions",
      addMilestone: "Add Milestone",
      itemDescription: "Item Description",
      quantity: "Quantity",
      unitPrice: "Unit Price",
      deliveryTerms: "Delivery Terms",
      addItem: "Add Item",
      principalAmount: "Principal Amount",
      installmentAmount: "Installment Amount",
      installmentDueDate: "Due Date",
      lateFeePercentage: "Late Fee Percentage",
      addInstallment: "Add Installment",
      effectiveDate: "Effective Date",
      confidentialityPeriod: "Confidentiality Period (years)",
      purpose: "Purpose of Agreement",
      error: "Please fill in all required fields",
      next: "Next"
    },
    am: {
      title: "የተወሰኑ ዝርዝሮች",
      subtitle: "የስምምነትዎን የተወሰኑ ዝርዝሮች ያስገቡ",
      servicesDescription: "የአገልግሎት መግ��ጫ",
      milestoneDescription: "የደረጃ መግለጫ",
      milestoneDate: "የደረጃ ቀን",
      revisions: "የማሻሻያ ብዛት",
      addMilestone: "ደረጃ ጨምር",
      itemDescription: "የእቃ መግለጫ",
      quantity: "ብዛት",
      unitPrice: "የአንድ እቃ ዋጋ",
      deliveryTerms: "የመላኪያ ውሎች",
      addItem: "እቃ ጨምር",
      principalAmount: "ዋና መጠን",
      installmentAmount: "የክፍያ መጠን",
      installmentDueDate: "የክፍያ ቀን",
      lateFeePercentage: "የዘግይቶ ክፍያ መቶኛ",
      addInstallment: "ክፍያ ጨምር",
      effectiveDate: "የመጀመሪያ ቀን",
      confidentialityPeriod: "የምስጢር ጊዜ (በዓመታት)",
      purpose: "የስምምነቱ ዓላማ",
      error: "እባክዎ ሁሉንም አስፈላጊ መስኮች ይሙሉ",
      next: "ቀጣይ"
    },
  }[currentLanguage];

  const handleNext = () => {
    if (!contractType) {
      toast.error(t.error);
      return;
    }
    if (contractType === "service" && (!specificDetails.servicesDescription || !specificDetails.milestones?.length)) {
      toast.error(t.error);
      return;
    }
    if (contractType === "goods" && (!specificDetails.items?.length || !specificDetails.deliveryTerms)) {
      toast.error(t.error);
      return;
    }
    if (contractType === "loan" && (!specificDetails.principalAmount || !specificDetails.installments?.length)) {
      toast.error(t.error);
      return;
    }
    if (contractType === "nda" && (!specificDetails.effectiveDate || !specificDetails.confidentialityPeriod || !specificDetails.purpose)) {
      toast.error(t.error);
      return;
    }
    onNext({ specificDetails });
  };

  const renderServiceFields = () => {
    const milestones = specificDetails.milestones || [{ description: "", date: "" }];
    const updateMilestone = (index: number, field: string, value: string) => {
      const newMilestones = [...milestones];
      newMilestones[index] = { ...newMilestones[index], [field]: value };
      setSpecificDetails({ ...specificDetails, milestones: newMilestones });
    };

    return (
      <div className="space-y-4">
        <div>
          <Label htmlFor="servicesDescription">{t.servicesDescription}</Label>
          <Input
            id="servicesDescription"
            value={specificDetails.servicesDescription || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, servicesDescription: e.target.value })}
            placeholder={t.servicesDescription}
          />
        </div>
        {milestones.map((milestone, index) => (
          <div key={index} className="space-y-2">
            <Label htmlFor={`milestoneDescription-${index}`}>{t.milestoneDescription} {index + 1}</Label>
            <Input
              id={`milestoneDescription-${index}`}
              value={milestone.description}
              onChange={(e) => updateMilestone(index, "description", e.target.value)}
              placeholder={t.milestoneDescription}
            />
            <Label htmlFor={`milestoneDate-${index}`}>{t.milestoneDate}</Label>
            <Input
              id={`milestoneDate-${index}`}
              type="date"
              value={milestone.date}
              onChange={(e) => updateMilestone(index, "date", e.target.value)}
              placeholder={t.milestoneDate}
            />
          </div>
        ))}
        <Button
          variant="outline"
          onClick={() => setSpecificDetails({ ...specificDetails, milestones: [...milestones, { description: "", date: "" }] })}
        >
          {t.addMilestone}
        </Button>
        <div>
          <Label htmlFor="revisions">{t.revisions}</Label>
          <Input
            id="revisions"
            type="number"
            value={specificDetails.revisions || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, revisions: parseInt(e.target.value) || 0 })}
            placeholder={t.revisions}
          />
        </div>
      </div>
    );
  };

  const renderGoodsFields = () => {
    const items = specificDetails.items || [{ description: "", quantity: 0, unitPrice: 0 }];
    const updateItem = (index: number, field: string, value: string | number) => {
      const newItems = [...items];
      newItems[index] = { ...newItems[index], [field]: value };
      setSpecificDetails({ ...specificDetails, items: newItems });
    };

    return (
      <div className="space-y-4">
        {items.map((item, index) => (
          <div key={index} className="space-y-2">
            <Label htmlFor={`itemDescription-${index}`}>{t.itemDescription} {index + 1}</Label>
            <Input
              id={`itemDescription-${index}`}
              value={item.description}
              onChange={(e) => updateItem(index, "description", e.target.value)}
              placeholder={t.itemDescription}
            />
            <Label htmlFor={`quantity-${index}`}>{t.quantity}</Label>
            <Input
              id={`quantity-${index}`}
              type="number"
              value={item.quantity}
              onChange={(e) => updateItem(index, "quantity", parseInt(e.target.value) || 0)}
              placeholder={t.quantity}
            />
            <Label htmlFor={`unitPrice-${index}`}>{t.unitPrice}</Label>
            <Input
              id={`unitPrice-${index}`}
              type="number"
              value={item.unitPrice}
              onChange={(e) => updateItem(index, "unitPrice", parseFloat(e.target.value) || 0)}
              placeholder={t.unitPrice}
            />
          </div>
        ))}
        <Button
          variant="outline"
          onClick={() => setSpecificDetails({ ...specificDetails, items: [...items, { description: "", quantity: 0, unitPrice: 0 }] })}
        >
          {t.addItem}
        </Button>
        <div>
          <Label htmlFor="deliveryTerms">{t.deliveryTerms}</Label>
          <Input
            id="deliveryTerms"
            value={specificDetails.deliveryTerms || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, deliveryTerms: e.target.value })}
            placeholder={t.deliveryTerms}
          />
        </div>
      </div>
    );
  };

  const renderLoanFields = () => {
    const installments = specificDetails.installments || [{ amount: 0, dueDate: "" }];
    const updateInstallment = (index: number, field: string, value: string | number) => {
      const newInstallments = [...installments];
      newInstallments[index] = { ...newInstallments[index], [field]: value };
      setSpecificDetails({ ...specificDetails, installments: newInstallments });
    };

    return (
      <div className="space-y-4">
        <div>
          <Label htmlFor="principalAmount">{t.principalAmount}</Label>
          <Input
            id="principalAmount"
            type="number"
            value={specificDetails.principalAmount || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, principalAmount: parseFloat(e.target.value) || 0 })}
            placeholder={t.principalAmount}
          />
        </div>
        {installments.map((installment, index) => (
          <div key={index} className="space-y-2">
            <Label htmlFor={`installmentAmount-${index}`}>{t.installmentAmount} {index + 1}</Label>
            <Input
              id={`installmentAmount-${index}`}
              type="number"
              value={installment.amount}
              onChange={(e) => updateInstallment(index, "amount", parseFloat(e.target.value) || 0)}
              placeholder={t.installmentAmount}
            />
            <Label htmlFor={`installmentDueDate-${index}`}>{t.installmentDueDate}</Label>
            <Input
              id={`installmentDueDate-${index}`}
              type="date"
              value={installment.dueDate}
              onChange={(e) => updateInstallment(index, "dueDate", e.target.value)}
              placeholder={t.installmentDueDate}
            />
          </div>
        ))}
        <Button
          variant="outline"
          onClick={() => setSpecificDetails({ ...specificDetails, installments: [...installments, { amount: 0, dueDate: "" }] })}
        >
          {t.addInstallment}
        </Button>
        <div>
          <Label htmlFor="lateFeePercentage">{t.lateFeePercentage}</Label>
          <Input
            id="lateFeePercentage"
            type="number"
            value={specificDetails.lateFeePercentage || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, lateFeePercentage: parseFloat(e.target.value) || 0 })}
            placeholder={t.lateFeePercentage}
          />
        </div>
      </div>
    );
  };

  const renderNDAFields = () => {
    return (
      <div className="space-y-4">
        <div>
          <Label htmlFor="effectiveDate">{t.effectiveDate}</Label>
          <Input
            id="effectiveDate"
            type="date"
            value={specificDetails.effectiveDate || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, effectiveDate: e.target.value })}
            placeholder={t.effectiveDate}
          />
        </div>
        <div>
          <Label htmlFor="confidentialityPeriod">{t.confidentialityPeriod}</Label>
          <Input
            id="confidentialityPeriod"
            type="number"
            value={specificDetails.confidentialityPeriod || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, confidentialityPeriod: parseInt(e.target.value) || 0 })}
            placeholder={t.confidentialityPeriod}
          />
        </div>
        <div>
          <Label htmlFor="purpose">{t.purpose}</Label>
          <Input
            id="purpose"
            value={specificDetails.purpose || ""}
            onChange={(e) => setSpecificDetails({ ...specificDetails, purpose: e.target.value })}
            placeholder={t.purpose}
          />
        </div>
      </div>
    );
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>{t.title}</CardTitle>
        <p className="text-sm text-gray-600">{t.subtitle}</p>
      </CardHeader>
      <CardContent className="space-y-6">
        {contractType === "service" && renderServiceFields()}
        {contractType === "goods" && renderGoodsFields()}
        {contractType === "loan" && renderLoanFields()}
        {contractType === "nda" && renderNDAFields()}
        <Button
          onClick={handleNext}
          className="bg-gray-800 hover:bg-gray-700 text-white w-full"
        >
          {t.next}
        </Button>
      </CardContent>
    </Card>
  );
}