"use client";

import React from "react";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Globe, FileText, Users, DollarSign, Calendar, Settings, Eye } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { Loader2 } from "lucide-react";
import { StepIndicator } from "@/components/wizard/StepIndicator";
import ChooseContractType from "@/components/wizard/steps/ChooseContractType";
import LanguageAndDescription from "@/components/wizard/steps/LanguageAndDescription";
import {PartiesInformation} from "@/components/wizard/steps/PartiesInformation";
import CommonDetails from "@/components/wizard/steps/CommonDetails";
import SpecificDetails from "@/components/wizard/steps/SpecificDetails";
import ContractPreview from "@/components/wizard/steps/ContractPreview";

export interface Step {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

export type Language = "en" | "am";

export interface ContractData {
  contractType?: string;
  agreementLanguage?: "en" | "am";
  description?: string;
  parties?: { fullName: string; phone: string; email: string }[];
  commonDetails?: {
    location: string;
    totalAmount: number;
    currency: "ETB" | "USD" | "EUR";
    startDate: string;
    endDate: string;
    dueDates: string[];
  };
  specificDetails?: {
    servicesDescription?: string;
    milestones?: { description: string; date: string }[];
    revisions?: number;
    items?: { description: string; quantity: number; unitPrice: number }[];
    deliveryTerms?: string;
    principalAmount?: number;
    installments?: { amount: number; dueDate: string }[];
    lateFeePercentage?: number;
    effectiveDate?: string;
    confidentialityPeriod?: number;
    purpose?: string;
  };
}

interface ContractWizardProps {
  onBackToDashboard?: () => void;
}

export function ContractWizard({ onBackToDashboard }: ContractWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [currentLanguage, setCurrentLanguage] = useState<Language>("en");
  const [contractData, setContractData] = useState<ContractData>({});
  const [isCheckingComplexity, setIsCheckingComplexity] = useState(false);

  const steps: Step[] = [
    { id: "type", label: currentLanguage === "en" ? "Contract Type" : "የውል አይነት", icon: FileText },
    { id: "language", label: currentLanguage === "en" ? "Language and Description" : "ቋንቋ እና መግለጫ", icon: Globe },
    { id: "parties", label: currentLanguage === "en" ? "Parties" : "ተዋዋዮች", icon: Users },
    { id: "common", label: currentLanguage === "en" ? "Common Details" : "የጋራ ዝርዝሮች", icon: DollarSign },
    { id: "specific", label: currentLanguage === "en" ? "Specific Details" : "የተወሰኑ ዝርዝሮች", icon: Settings },
    { id: "preview", label: currentLanguage === "en" ? "Preview" : "ቅድመ እይታ", icon: Eye },
  ];

  const t = {
    en: {
      title: "Contract Wizard",
      step: "Step",
      of: "of",
      back: "Back",
      next: "Next",
      finish: "Create Contract",
    },
    am: {
      title: "የውል አዘጋጅ",
      step: "ደረጃ",
      of: "ከ",
      back: "ተመለስ",
      next: "ቀጣይ",
      finish: "ውል ፍጠር",
    },
  }[currentLanguage];

  const handleNext = (data: Partial<ContractData>) => {
    setContractData({ ...contractData, ...data });

    if (currentStep === 1) {
      setIsCheckingComplexity(true);
      setTimeout(() => {
        setIsCheckingComplexity(false);
        setCurrentStep(currentStep + 1);
      }, 1000);
    } else if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      toast.success(t.finish);
      if (onBackToDashboard) onBackToDashboard();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else if (onBackToDashboard) {
      onBackToDashboard();
    }
  };

  const handleLanguageToggle = () => {
    setCurrentLanguage((prev) => (prev === "en" ? "am" : "en"));
  };

  if (isCheckingComplexity) {
    return (
      <div className={`h-full flex flex-col bg-gray-100 ${currentLanguage === "am" ? "font-ethiopic" : ""}`}>
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              disabled={currentStep === 0 && !onBackToDashboard}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              {t.back}
            </Button>
            <div>
              <h1 className="text-xl font-semibold">{t.title}</h1>
              <p className="text-sm text-gray-500">{t.step} {currentStep + 1} {t.of} {steps.length}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLanguageToggle}
            className="flex items-center bg-white text-black border border-gray-200 hover:bg-teal-500 hover:text-white transition-colors"
          >
            <Globe className="h-4 w-4 mr-2" />
            {currentLanguage === "en" ? "አማርኛ" : "English"}
          </Button>
        </div>
        <div className="flex-1 overflow-auto flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardContent className="p-6 flex flex-col items-center">
              <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
              <p className="mt-4 text-lg text-gray-700">
                {currentLanguage === "en" ? "Checking complexity..." : "ውስብስብነት በመፈተሽ ላይ..."}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className={`h-full flex flex-col bg-gray-100 ${currentLanguage === "am" ? "font-ethiopic" : ""}`}>
      <div className="px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBack}
            disabled={currentStep === 0 && !onBackToDashboard}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            {t.back}
          </Button>
          <div>
            <h1 className="text-xl font-semibold">{t.title}</h1>
            <p className="text-sm text-gray-500">{t.step} {currentStep + 1} {t.of} {steps.length}</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleLanguageToggle}
          className="flex items-center bg-white text-black border border-gray-200 hover:bg-teal-500 hover:text-white transition-colors"
        >
          <Globe className="h-4 w-4 mr-2" />
          {currentLanguage === "en" ? "አማርኛ" : "English"}
        </Button>
      </div>
      <div className="px-6 py-4">
        <StepIndicator steps={steps} currentStep={currentStep} currentLanguage={currentLanguage} />
      </div>
      <div className="flex-1 overflow-auto px-6 py-4">
        {currentStep === 0 && <ChooseContractType currentLanguage={currentLanguage} onNext={handleNext} />}
        {currentStep === 1 && <LanguageAndDescription currentLanguage={currentLanguage} onNext={handleNext} />}
        {currentStep === 2 && (
          <PartiesInformation
            currentLanguage={currentLanguage}
            onNext={handleNext}
            contractType={contractData.contractType}
          />
        )}
        {currentStep === 3 && (
          <CommonDetails
            currentLanguage={currentLanguage}
            onNext={handleNext}
            contractType={contractData.contractType}
          />
        )}
        {currentStep === 4 && (
          <SpecificDetails
            currentLanguage={currentLanguage}
            onNext={handleNext}
            contractType={contractData.contractType}
          />
        )}
        {currentStep === 5 && <ContractPreview currentLanguage={currentLanguage} contractData={contractData} />}
      </div>
      <div className="px-6 py-4 flex justify-between">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleBack}
          disabled={currentStep === 0 && !onBackToDashboard}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          {t.back}
        </Button>
        {currentStep < steps.length - 1 ? (
          <Button
            onClick={() => handleNext({})}
            className="bg-gray-800 hover:bg-gray-700 text-white"
          >
            {t.next}
            <ArrowLeft className="h-4 w-4 ml-2 rotate-180" />
          </Button>
        ) : (
          <div className="space-x-2">
            <Button variant="outline">{currentLanguage === "en" ? "Export" : "ወደ ውጭ"}</Button>
            <Button
              onClick={() => handleNext({})}
              className="bg-slate-800 hover:bg-slate-700 text-white"
            >
              {t.finish}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}